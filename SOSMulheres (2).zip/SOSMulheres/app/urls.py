from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('alerta-rapido/', views.alerta_rapido_create, name='alerta_rapido_create'),
    path('avaliacao-risco/', views.avaliacao_risco_create, name='avaliacao_risco_create'),
    path('denuncia/', views.denuncia_create, name='denuncia_create'),
    path('informacao/', views.informacao_create, name='informacao_create'),
    path('rede-apoio/', views.rede_apoio_create, name='rede_apoio_create'),
]
