from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import AlertaRapidoForm, AvaliacaoRiscoForm, DenunciaForm, InformacaoForm

def home(request):
    return render(request, 'home.html')

def alerta_rapido_create(request):
    if request.method == 'POST':
        form = AlertaRapidoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Alerta Rápido enviado com sucesso.')
            return redirect('home')
    else:
        form = AlertaRapidoForm()
    return render(request, 'form_template.html', {'form': form, 'titulo': 'Alerta Rápido'})

def avaliacao_risco_create(request):
    if request.method == 'POST':
        form = AvaliacaoRiscoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Avaliação de Risco enviada com sucesso.')
            return redirect('home')
    else:
        form = AvaliacaoRiscoForm()
    return render(request, 'form_template.html', {'form': form, 'titulo': 'Avaliação de Risco'})

def denuncia_create(request):
    if request.method == 'POST':
        form = DenunciaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Denúncia enviada com sucesso.')
            return redirect('home')
    else:
        form = DenunciaForm()
    return render(request, 'form_template.html', {'form': form, 'titulo': 'Denúncia'})

def informacao_create(request):
    if request.method == 'POST':
        form = InformacaoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Informação enviada com sucesso.')
            return redirect('home')
    else:
        form = InformacaoForm()
    return render(request, 'form_template.html', {'form': form, 'titulo': 'Informação'})

def rede_apoio_create(request):
    # Página informativa inspirada no Mapa do Acolhimento
    return render(request, 'rede_apoio.html')
